'use strict';
// core/gcstatus.js — @crysnovax/baileys group-status sender (groupStatus: true).
//
// Single status entry point. Every link status is resolved through core/statusPreview.js,
// which guarantees a large jpegThumbnail BUFFER (a remote thumbnailUrl is ignored on the
// status ring). Plain text / font / colour statuses and media statuses pass straight through.

const logger = require('./logger');
const linkPreviewCache = require('./linkPreviewCache');
const { extractUrls, normalizeThumbnailBuffer } = require('./linkPreview');
const { resolveStatusPreview } = require('./statusPreview');

function reviveBuffer(v) {
    if (!v) return null;
    if (Buffer.isBuffer(v)) return v.length ? v : null;
    // Baileys returns protobuf byte fields as Uint8Array, not Buffer
    if (v instanceof Uint8Array) { const b = Buffer.from(v); return b.length ? b : null; }
    if (v.type === 'Buffer' && Array.isArray(v.data)) { const b = Buffer.from(v.data); return b.length ? b : null; }
    return null;
}

// Pull the human text out of a relayed source message.
function sourceText(sourceMessage) {
    if (!sourceMessage) return '';
    return sourceMessage.extendedTextMessage?.text
        || sourceMessage.conversation
        || '';
}

// Does this status carry a link anywhere (post text, source text, or source matchedText)?
function findStatusUrl(postText, sourceMessage) {
    const fromText = extractUrls(String(postText || ''))[0];
    if (fromText) return fromText;
    const ext = sourceMessage?.extendedTextMessage;
    if (ext) {
        const fromMatched = ext.matchedText || ext.canonicalUrl || '';
        if (extractUrls(fromMatched)[0]) return extractUrls(fromMatched)[0];
        const fromSrcText = extractUrls(String(ext.text || ''))[0];
        if (fromSrcText) return fromSrcText;
    }
    return null;
}

async function sendGroupStatus(sock, groupJid, content, opts = {}) {
    if (!groupJid?.endsWith('@g.us')) throw new Error('Requires a valid @g.us JID');
    if (!sock?.user) throw new Error('Socket not connected');

    try { await sock.updateStatusPrivacy('all'); } catch {}

    const { sourceMessage = null, sourceContextInfo = null } = opts;
    const ext = sourceMessage?.extendedTextMessage || null;

    // Explicit style fields supplied by the caller (e.g. magiccast's rotating colour/font).
    // These take precedence over any style relayed from a source message.
    const explicitBg   = Number.isFinite(content?.backgroundArgb) ? content.backgroundArgb : null;
    const explicitFont = (content?.font !== undefined && content?.font !== null) ? content.font : null;
    const styleFields  = {
        ...(explicitBg   != null ? { backgroundArgb: explicitBg }   : {}),
        ...(explicitFont != null ? { font:           explicitFont } : {}),
    };

    // ── PATH A: media status (image / video) ─────────────────────────────────
    if (content.image || content.video) {
        const result = await sock.sendMessage(groupJid, { ...content, groupStatus: true });
        logger.info(`[GCStatus] Ring (media) -> ${groupJid}`);
        return result;
    }

    // The visible status text: prefer the caller's text (command/aesthetic-wrapped),
    // fall back to the relayed source text. Never post the raw command itself.
    const postText = (content.text != null && content.text !== '')
        ? String(content.text)
        : sourceText(sourceMessage);

    // Opportunistically learn this preview for future reuse.
    if (ext && postText) {
        try { linkPreviewCache.cacheFromMessage({ message: { extendedTextMessage: ext } }, postText); } catch {}
    }

    const statusUrl = findStatusUrl(postText, sourceMessage);

    // ── PATH B: link status → unified resolver (Tier 1 sent / Tier 2 cache / Tier 3 build) ──
    if (statusUrl) {
        const resolved = await resolveStatusPreview({
            sock,
            text: postText || statusUrl,
            sourceMessage,
            sourceContextInfo: sourceContextInfo || ext?.contextInfo || content.contextInfo || null,
        }).catch((e) => { logger.warn(`[GCStatus] preview resolve failed: ${e.message}`); return null; });

        if (resolved?.externalAdReply) {
            const result = await sock.sendMessage(groupJid, {
                text: postText || statusUrl,
                contextInfo: {
                    matchedText:    resolved.matchedText,
                    canonicalUrl:   resolved.canonicalUrl,
                    'matched-text': resolved.matchedText,
                    externalAdReply: resolved.externalAdReply,
                },
                ...styleFields,
                groupStatus: true,
            });
            logger.info(`[GCStatus] Ring (link card, large thumb) -> ${groupJid}`);
            return result;
        }
        // resolver returned nothing usable — fall through to plain text
    }

    // ── PATH C: caller already built a contextInfo.externalAdReply ────────────
    // Honour it, but make sure the thumbnail is a buffer (status ignores thumbnailUrl).
    if (content.contextInfo?.externalAdReply) {
        const ad = content.contextInfo.externalAdReply;
        ad.renderLargerThumbnail = true;
        const buf = reviveBuffer(ad.jpegThumbnail);
        if (buf) {
            ad.jpegThumbnail = await normalizeThumbnailBuffer(buf).catch(() => buf) || buf;
            delete ad.thumbnailUrl;
        }
        const result = await sock.sendMessage(groupJid, { ...content, groupStatus: true });
        logger.info(`[GCStatus] Ring (prebuilt contextInfo) -> ${groupJid}`);
        return result;
    }

    // ── PATH D: plain text / font / colour status ──
    // Explicit caller style (magiccast) wins; otherwise relay the source message's style as-is.
    if (ext) {
        const relayStyle = {
            ...(ext.backgroundArgb ? { backgroundArgb: ext.backgroundArgb } : {}),
            ...(ext.font           ? { font:           ext.font }           : {}),
        };
        const result = await sock.sendMessage(groupJid, {
            text: postText || '🔱',
            ...relayStyle,
            ...styleFields, // explicit overrides relayed style
            groupStatus: true,
        });
        logger.info(`[GCStatus] Ring (text/style) -> ${groupJid}`);
        return result;
    }

    const result = await sock.sendMessage(groupJid, { text: postText || '🔱', ...styleFields, groupStatus: true });
    logger.info(`[GCStatus] Ring (plain${explicitBg != null ? '+colour' : ''}) -> ${groupJid}`);
    return result;
}

module.exports = { sendGroupStatus };
