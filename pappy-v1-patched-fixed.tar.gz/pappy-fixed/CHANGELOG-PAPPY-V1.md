# Pappy V1 — Patch Notes

This patch fixes two broken features, adds a new broadcast command, redesigns the menu,
adds new commands + Baileys capabilities, and unifies branding to **Pappy V1**.

> Note: changes are code-level and were not run against live WhatsApp in the build sandbox.
> Deploy to your VPS and test; a couple of items (native album, buttons/list rendering) depend
> on the WhatsApp client/build and fail gracefully if unsupported.

---

## 1. Fixed: `.song` poll never downloaded the tapped track
**Files:** `core/whatsapp.js`, `plugins/pappy-core.js`

The vote handler misused Baileys' poll API — it called `getAggregateVotesInPollMessage` with a
non-existent `encKey` argument against a *still-encrypted* vote, and read the secret from the
wrong field. On top of that, the socket runs `emitOwnEvents:false`, so the bot's own poll was
never cached, meaning the handler bailed before it even tried.

- `resolveSongPollSelections()` rewritten to decrypt votes correctly: reads the poll
  `messageContextInfo.messageSecret`, decrypts via `decryptPollVote`, then aggregates option
  names with the correct single-argument `getAggregateVotesInPollMessage`. Handles both
  already-decrypted (`messages.update`) and raw-encrypted (`messages.upsert`) votes.
- `.song` now caches the poll-creation message (with its `messageSecret`) into `messageCache`
  and `_songPollLookup`, so the handler can find and decrypt the vote.

## 2. Improved: full-size link-preview thumbnails
**File:** `core/linkPreview.js`

- Thumbnails are no longer cropped to a 1024 square — aspect ratio is preserved (`fit:'inside'`)
  so wide images render as WhatsApp's big rectangular card. Size ceiling raised to 1280px / 320KB.
- Chat previews now embed a large `jpegThumbnail` **buffer** (WhatsApp only renders the big card
  from a buffer; a bare `thumbnailUrl` produces the small card) while keeping the URL as a
  hi-res / Open-button fallback. `renderLargerThumbnail` + `mediaType:1` set consistently.

## 3. New: `.magiccast` (a.k.a. `.magic cast`)
**Files:** `plugins/pappy-broadcast.js`, `core/bullEngine.js`, `core/gcstatus.js`, `core/magicPalette.js`

Like `.godcast`, but every group it lands in gets a **different colored status background + font +
design** — one broadcast paints a rainbow of distinct, aesthetic status cards.

- `core/magicPalette.js`: 16 curated dark/jewel background colors paired with status fonts; a
  rotating picker (group-JID hash + rotating cursor) guarantees neighbours differ and the same
  group shifts color on each new broadcast.
- Worker applies the per-group color/font + a rotating template; `gcstatus` now honors explicit
  `backgroundArgb`/`font` on text **and** link statuses.
- Shares godcast's paced, concurrency-1 queue lane + Ghost Protocol.

## 4. Redesigned: `.menu` → Pappy V1
**Files:** `modules/menuEngine.js`, `modules/uiTheme.js`, `plugins/pappy-core.js`

- Clean **PAPPY V1** header + profile card: name, number, prefix, command count, used-count,
  uptime, system RAM (GB-aware), live date/time.
- Prefix is now **dynamic** — commands render with the live prefix instead of a hardcoded dot.
- Category icons updated for the real module set (Broadcast, Magic, Intel, Stealth, Strike,
  Triggers, Growth Engine, Utility, Aesthetic, …); unknown categories still auto-appear.

## 5. New commands
**File:** `plugins/pappy-extra.js`

- `.save` — reply to any image/video/audio/file to copy it to your DM (status / disappearing-proof).
- `.ssweb <url>` — full-page website screenshot.

(`.vv` and `.quote` already existed in the FLEX suite, so they weren't duplicated.)

## 6. Plugin look audit
- Branding unified to **Pappy V1**: sticker pack name (`Ω Pappy Ultimate` → `⚡ Pappy V1`) and the
  Telegram "OMEGA RADAR" dumps (`pappy-radar.js`).
- Verified all plugin outputs are clean and professional (no debug/raw output leaking to users).

## 7. Baileys "flex" additions
**File:** `plugins/pappy-magic.js`

- `.btns Title | Body | Btn1 | Btn2` — interactive quick-reply buttons.
- `.list Title | Body | ButtonText | row1, row2, row3` — sectioned list menu.
- `.album <url1> <url2> …` — send 2–10 images as a native album (sequential fallback).
- Already present and confirmed working: `.vv`/`.viewonce`, `.react`, `.animate` (live edits),
  `.poll`, `.forward`, `.location`, `.vcard`, `.event`, `.tovn`.
