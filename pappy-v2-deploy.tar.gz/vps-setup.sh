#!/bin/bash
# ── Pappy Bot VPS Setup Script ────────────────────────────────
# Run once on a fresh Ubuntu/Debian VPS: bash vps-setup.sh

set -e
echo "🚀 Pappy Bot VPS Setup Starting..."

# ── 1. Install system dependencies ───────────────────────────
echo "📦 Installing system packages..."
apt-get update -qq
apt-get install -y curl git redis-server ffmpeg

# ── 2. Install Node.js 20 LTS ────────────────────────────────
if ! command -v node &>/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d 'v')" -lt 18 ]]; then
    echo "📦 Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo "✅ Node $(node -v)"

# ── 3. Install PM2 globally ───────────────────────────────────
if ! command -v pm2 &>/dev/null; then
    echo "📦 Installing PM2..."
    npm install -g pm2
fi
echo "✅ PM2 $(pm2 --version)"

# ── 4. Start Redis ────────────────────────────────────────────
echo "🔴 Starting Redis..."
systemctl enable redis-server
systemctl start redis-server
echo "✅ Redis running"

# ── 5. Install bot dependencies ───────────────────────────────
echo "📦 Installing bot dependencies..."
npm install --legacy-peer-deps

# ── 6. Create data directories ────────────────────────────────
mkdir -p data/sessions data/logs data/temp_media data/sticker_cache data/yt_cache

# ── 7. Copy .env.example if no .env exists ───────────────────
if [ ! -f .env ]; then
    cp .env.example .env
    echo ""
    echo "⚠️  IMPORTANT: Edit .env with your credentials before starting:"
    echo "    nano .env"
    echo ""
fi

echo "✅ Setup complete!"
echo ""
echo "📋 Next steps:"
echo "   1. Edit your .env file: nano .env"
echo "   2. Start the bot:       pm2 start ecosystem.config.js"
echo "   3. Save PM2 startup:    pm2 save && pm2 startup"
echo "   4. View logs:           pm2 logs pappy-bot"
