#!/bin/bash
# ─────────────────────────────────────────────────────────
#  PAPPY V2 — VPS Setup Script
#  Ubuntu 22.04 / Debian 12 compatible
#  Run once: bash setup-vps.sh
# ─────────────────────────────────────────────────────────

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC}   $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
die()   { echo -e "${RED}[ERR]${NC}  $1"; exit 1; }

echo -e "${CYAN}"
echo "  ██████╗  █████╗ ██████╗ ██████╗ ██╗   ██╗"
echo "  ██╔══██╗██╔══██╗██╔══██╗██╔══██╗╚██╗ ██╔╝"
echo "  ██████╔╝███████║██████╔╝██████╔╝ ╚████╔╝ "
echo "  ██╔═══╝ ██╔══██║██╔═══╝ ██╔═══╝   ╚██╔╝  "
echo "  ██║     ██║  ██║██║     ██║        ██║   "
echo "  ╚═╝     ╚═╝  ╚═╝╚═╝     ╚═╝        ╚═╝   "
echo -e "  V2 — VPS SETUP${NC}"
echo ""

# ── 1. Node.js 20 ──────────────────────────────────────────────────────────────
if ! command -v node &>/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 20 ]]; then
  info "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
  ok "Node.js $(node -v) installed"
else
  ok "Node.js $(node -v) already installed"
fi

# ── 2. Redis ───────────────────────────────────────────────────────────────────
if ! command -v redis-server &>/dev/null; then
  info "Installing Redis..."
  sudo apt-get update -qq
  sudo apt-get install -y redis-server
  sudo systemctl enable redis-server
  sudo systemctl start redis-server
  ok "Redis installed and started"
else
  sudo systemctl start redis-server 2>/dev/null || true
  ok "Redis already installed"
fi

# ── 3. System deps (sharp needs libvips) ───────────────────────────────────────
info "Installing system dependencies..."
sudo apt-get install -y build-essential libvips-dev python3 ffmpeg curl 2>/dev/null | tail -1
ok "System dependencies ready"

# ── 4. PM2 ─────────────────────────────────────────────────────────────────────
if ! command -v pm2 &>/dev/null; then
  info "Installing PM2..."
  sudo npm install -g pm2
  ok "PM2 installed"
else
  ok "PM2 already installed"
fi

# ── 5. Bot deps ────────────────────────────────────────────────────────────────
info "Installing bot dependencies (this may take a minute)..."
npm install --legacy-peer-deps 2>&1 | tail -3
ok "npm install complete"

info "Applying Baileys patches..."
bash patches/apply-patches.sh
ok "Patches applied"

# ── 6. .env check ──────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  warn ".env not found — creating from template..."
  cp .env.example .env
  echo ""
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${YELLOW}  Edit .env with your credentials before starting:${NC}"
  echo -e "${YELLOW}    nano .env${NC}"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo ""
  exit 0
else
  ok ".env found"
fi

# ── 7. Create data dirs ────────────────────────────────────────────────────────
mkdir -p data/sessions data/temp_media data/logs data/sticker_cache
ok "Data directories ready"

# ── 8. Start with PM2 ──────────────────────────────────────────────────────────
echo ""
info "Starting Pappy V2 with PM2..."
pm2 delete pappy-v2 2>/dev/null || true
pm2 start index.js --name pappy-v2 --max-memory-restart 800M \
  --restart-delay 3000 --max-restarts 20 \
  --log data/logs/pm2-out.log --error data/logs/pm2-err.log
pm2 save
pm2 startup | tail -1 | bash 2>/dev/null || true

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  ✅ PAPPY V2 IS RUNNING!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "  Monitor : pm2 logs pappy-v2"
echo "  Status  : pm2 status"
echo "  Stop    : pm2 stop pappy-v2"
echo "  Restart : pm2 restart pappy-v2"
echo ""
echo "  Now open Telegram and send /pair <your_number> to the bot"
echo ""
