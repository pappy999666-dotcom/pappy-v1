#!/usr/bin/env bash
set -e

echo "🔧 Starting services..."

# Start Redis if not already running
if ! pgrep -x redis-server > /dev/null; then
    echo "▶ Starting Redis..."
    redis-server --daemonize yes --logfile /tmp/redis.log --save ""
    sleep 1
    echo "✅ Redis started"
else
    echo "✅ Redis already running"
fi

# Start MongoDB if not already running
if ! pgrep -x mongod > /dev/null; then
    echo "▶ Starting MongoDB..."
    mkdir -p /tmp/mongodb
    mongod --dbpath /tmp/mongodb --logpath /tmp/mongodb.log --fork --quiet
    sleep 2
    echo "✅ MongoDB started"
else
    echo "✅ MongoDB already running"
fi

echo "🚀 Starting Pappy Bot..."
cd "$(dirname "$0")"
node --expose-gc index.js
