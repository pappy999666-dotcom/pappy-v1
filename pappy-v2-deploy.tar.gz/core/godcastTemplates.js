'use strict';
// core/godcastTemplates.js — THREE THEME PACKS
// Themes: 'cyber' (hacker), 'girly' (aesthetic), 'guys' (masculine)
// Switch globally with .setgodcasttmp <theme>

const fs   = require('fs');
const path = require('path');

const STORE_FILE = path.join(__dirname, '../data/godcast-group-templates.json');
const THEME_FILE = path.join(__dirname, '../data/godcast-theme.json');

let _store = {};
let _activeTheme = 'cyber';

function _loadStore() {
    try { if (fs.existsSync(STORE_FILE)) _store = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')) || {}; } catch { _store = {}; }
}
function _loadTheme() {
    try { if (fs.existsSync(THEME_FILE)) _activeTheme = JSON.parse(fs.readFileSync(THEME_FILE, 'utf8')).theme || 'cyber'; } catch {}
}

let _saveTimer = null;
function _saveStore() {
    if (_saveTimer) return;
    _saveTimer = setTimeout(() => {
        _saveTimer = null;
        try { fs.mkdirSync(path.dirname(STORE_FILE), { recursive: true }); fs.writeFileSync(STORE_FILE, JSON.stringify(_store, null, 2)); } catch {}
    }, 800);
    if (_saveTimer?.unref) _saveTimer.unref();
}
function _saveTheme() {
    try { fs.mkdirSync(path.dirname(THEME_FILE), { recursive: true }); fs.writeFileSync(THEME_FILE, JSON.stringify({ theme: _activeTheme }, null, 2)); } catch {}
}

_loadStore();
_loadTheme();

// ═══════════════════════════════════════════════════════════════════════════════
// CYBER / HACKER THEME (55 designs)
// ═══════════════════════════════════════════════════════════════════════════════
const CYBER_T = [

(l) => `> SYSTEM BREACH INITIATED\n▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n${l}\n▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\nACCESS GRANTED ↵`,

(l) => `01001000 SIGNAL DROPPED\n│▒░▒░▒░▒░▒░▒░▒░▒░▒│\n${l}\n│▒░▒░▒░▒░▒░▒░▒░▒░▒│\nDECODE BEFORE TIMEOUT`,

(l) => `⟨ NEURAL UPLINK ONLINE ⟩\n─═══════════════════─\n${l}\n─═══════════════════─\n⟨ SYNC OR MISS OUT ⟩`,

(l) => `🔐 ENCRYPTED CHANNEL\n▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄\n${l}\n▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄\nAUTHORIZED EYES ONLY 🔐`,

(l) => `◤◤ DARK SIGNAL LIVE ◥◥\n╔═══════════════════╗\n${l}\n╚═══════════════════╝\nTAP IN. CLOCK IS TICKING.`,

(l) => `👻 GHOST PROTOCOL ACTIVE\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n${l}\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\nTHIS LINK SELF-DESTRUCTS 👻`,

(l) => `⚠ ROOT ACCESS DROPPING\n━┿━┿━┿━┿━┿━┿━┿━┿━\n${l}\n━┿━┿━┿━┿━┿━┿━┿━┿━\n⚠ PLUG IN BEFORE IT WIPES`,

(l) => `[PAYLOAD DELIVERED]\n╠══════════════════╣\n${l}\n╠══════════════════╣\n[OPEN. EXECUTE. GO.]`,

(l) => `⌗ CYBER GRID UNLOCKED\n┼─┼─┼─┼─┼─┼─┼─┼─┼\n${l}\n┼─┼─┼─┼─┼─┼─┼─┼─┼\n⌗ CONNECT TO THE GRID`,

(l) => `🌐 DARKNET COORDINATES\n◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈\n${l}\n◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈\n🌐 TRACE WILL BE DELETED`,

(l) => `XOR CIPHER UNLOCKED ⚡\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n${l}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nKEY EXPIRES SOON ⚡`,

(l) => `[SYS] OVERRIDE IN PROGRESS\n◇━━━━━━━━━━━━━━━━━◇\n${l}\n◇━━━━━━━━━━━━━━━━━◇\n[SYS] JOIN BEFORE ROLLBACK`,

(l) => `▌CLASSIFIED DROP▐\n██████████████████\n${l}\n██████████████████\n▌AUTHORIZED ACCESS ONLY▐`,

(l) => `📡 SIGNAL INTERCEPTED\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n${l}\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n📡 TAP IN NOW`,

(l) => `</> CODE INJECTED\n› › › › › › › › › ›\n${l}\n‹ ‹ ‹ ‹ ‹ ‹ ‹ ‹ ‹ ‹\n</> RUN THE SCRIPT`,

(l) => `🔇 SILENT OPERATION\n·  ·  ·  ·  ·  ·  ·  ·\n${l}\n·  ·  ·  ·  ·  ·  ·  ·\n🔇 NO NOISE. JUST ENTRY.`,

(l) => `⬛ BLACK HAT EXCLUSIVE\n═══════════════════\n${l}\n═══════════════════\n⬛ ONE TIME ACCESS`,

(l) => `🔴 RED TEAM CHANNEL\n┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄\n${l}\n┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄\n🔴 BREACH WINDOW CLOSING`,

(l) => `🔓 FIREWALL BYPASSED\n⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫\n${l}\n⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪\n🔓 ENTER WHILE YOU CAN`,

(l) => `[ ZERO-DAY EXPLOIT ]\n━━━━━━━━━━━━━━━━━━━━\n${l}\n━━━━━━━━━━━━━━━━━━━━\n[ ACT BEFORE IT PATCHES ]`,

(l) => `☠ SHADOW DROP LIVE\n╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌\n${l}\n╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌\n☠ MOVE IN SILENCE`,

(l) => `⚡ PACKET INCOMING\n▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸\n${l}\n◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂\n⚡ CATCH IT BEFORE IT DROPS`,

(l) => `🔒 SECURE TUNNEL OPEN\n~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~\n${l}\n~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~\n🔒 ENTER BEFORE IT CLOSES`,

(l) => `🛡 VPN COORDINATES\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n${l}\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n🛡 MASKED. UNTRACEABLE.`,

(l) => `💾 DATA VAULT CRACKED\n▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬\n${l}\n▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬\n💾 DOWNLOAD BEFORE PURGE`,

(l) => `〔 STEALTH MODE ON 〕\n· ─ · ─ · ─ · ─ · ─\n${l}\n· ─ · ─ · ─ · ─ · ─\n〔 INVISIBLE. EXCLUSIVE. 〕`,

(l) => `☢ KILLSWITCH ARMED\n░░░░░░░░░░░░░░░░░░░\n${l}\n░░░░░░░░░░░░░░░░░░░\n☢ JOIN OR GET LEFT BEHIND`,

(l) => `$ sudo access --level=root\n╔─────────────────╗\n${l}\n╚─────────────────╝\n$ session expires in 60s`,

(l) => `⚠ ANOMALY DETECTED\n◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤\n${l}\n◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥\n⚠ INVESTIGATE NOW`,

(l) => `[PING] RESPONSE RECEIVED\n◆─────────────────◆\n${l}\n◆─────────────────◆\n[PING] LATENCY: NOW`,

(l) => `🌐 TRACEROUTE COMPLETE\n╠═════════════════╣\n${l}\n╠═════════════════╣\n🌐 DESTINATION FOUND`,

(l) => `01 BINARY INCOMING 10\n┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃\n${l}\n┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃\n01 DECODE AND ENTER 10`,

(l) => `🕳 DEEP WEB ACCESS\n⬡─⬡─⬡─⬡─⬡─⬡─⬡─⬡\n${l}\n⬡─⬡─⬡─⬡─⬡─⬡─⬡─⬡\n🕳 NO TRACE. NO RECORD.`,

(l) => `💀 EXPLOIT CHAIN LIVE\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n${l}\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n💀 EXECUTE BEFORE PATCH`,

(l) => `📦 SECURE DROP INCOMING\n⊱──────────────────⊰\n${l}\n⊱──────────────────⊰\n📦 COLLECT BEFORE PURGE`,

(l) => `🔭 RECON COMPLETE\n╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍\n${l}\n╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍\n🔭 TARGET ACQUIRED`,

(l) => `[ STATUS: FLOODING ]\n▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌\n${l}\n▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐\n[ TAP BEFORE OVERFLOW ]`,

(l) => `👁 INTERCEPTED IN TRANSIT\n◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇\n${l}\n◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇\n👁 YOU WERE WATCHED. ENTER.`,

(l) => `🔑 CIPHER LOCK BROKEN\n✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦\n${l}\n✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦\n🔑 KEY BURNS AFTER USE`,

(l) => `🖤 BLACK MIRROR SIGNAL\n║═══════════════════║\n${l}\n║═══════════════════║\n🖤 REFLECT. ENTER. VANISH.`,

(l) => `🔍 DEEP SCAN COMPLETE\n▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄\n${l}\n▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\n🔍 VERIFIED. ENTER.`,

(l) => `[ NODE DISCOVERED ]\n⟫─────────────────⟪\n${l}\n⟫─────────────────⟪\n[ CONNECT BEFORE TIMEOUT ]`,

(l) => `📻 FREQUENCY LOCKED IN\n≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋\n${l}\n≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋\n📻 TUNE IN NOW`,

(l) => `🧰 EXPLOIT KIT DEPLOYED\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n${l}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n🧰 USE BEFORE IT EXPIRES`,

(l) => `🌑 DARK OPS INITIATED\n·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣\n${l}\n·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣ ·̣\n🌑 SHADOW PROTOCOL. GO.`,

(l) => `🚨 INTRUSION ALERT\n┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼\n${l}\n┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼\n🚨 AUTHORIZED BREACH ONLY`,

(l) => `🔏 RSA KEY TRANSMITTED\n━━━━━━━━━━━━━━━━━━━━\n${l}\n━━━━━━━━━━━━━━━━━━━━\n🔏 DECRYPT AND ENTER`,

(l) => `🐛 WORM DEPLOYED\n►───────────────────►\n${l}\n◄───────────────────◄\n🐛 PROPAGATE. JOIN NOW.`,

(l) => `🌒 MIDNIGHT SIGNAL DROP\n╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌\n${l}\n╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌\n🌒 AFTER HOURS. ELITE ONLY.`,

(l) => `$ ssh elite@darkserver\n╔══[ CONNECTED ]══╗\n${l}\n╚═════════════════╝\n$ logout when done`,

(l) => `🚪 BACKDOOR DISCOVERED\n░█░█░█░█░█░█░█░█░█\n${l}\n░█░█░█░█░█░█░█░█░█\n🚪 SLIP IN. LEAVE NO TRACE.`,

(l) => `📡 FREQUENCY JAMMED\n⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗\n${l}\n⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗ ⌗\n📡 BYPASS THE NOISE`,

(l) => `🗝 SKELETON KEY ISSUED\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\n${l}\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\n🗝 ONE KEY. ONE CHANCE.`,

(l) => `♻ SYSTEM REBOOTING...\n[████████████░░░] 80%\n${l}\n[████████████████] DONE\n♻ BOOT INTO THE CHANNEL`,

(l) => `🖤 PRESTIGE DROP 🖤\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\n${l}\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\nNO NOISE. JUST ENTRY. 🖤`,

];

// ═══════════════════════════════════════════════════════════════════════════════
// GIRLY / AESTHETIC THEME (55 designs)
// ═══════════════════════════════════════════════════════════════════════════════
const GIRLY_T = [

(l) => `꒰ᵕ̈꒱ you're chosen ✦\n ꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦\n${l}\n ꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦\ntap before it closes ♡`,

(l) => `˗ˏˋ your invite is here ˊˎ˗\n· · ─ ─ · · ─ ─ · · ─ ─ · ·\n${l}\n· · ─ ─ · · ─ ─ · · ─ ─ · ·\n˗ˏˋ don't keep us waiting ˊˎ˗`,

(l) => `✿ not everyone gets this ✿\n❀ ─ · ─ · ─ · ─ · ─ · ─ ❀\n${l}\n❀ ─ · ─ · ─ · ─ · ─ · ─ ❀\nbut you do ✿`,

(l) => `♡ secret drop ♡\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n${l}\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\njoin before it closes ♡`,

(l) => `💎 exclusive access only\n◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇\n${l}\n◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇\nyou qualify 💎`,

(l) => `🦋 something special\n·  ·  ·  ·  ·  ·  ·  ·  ·  ·\n${l}\n·  ·  ·  ·  ·  ·  ·  ·  ·  ·\nflutter in ♡`,

(l) => `🍓 this one's different\n ୨─────────────────୧\n${l}\n ୨─────────────────୧\ntaste it 🍓`,

(l) => `☾ after hours drop ☽\n· · · · · · · · · · · · · ·\n${l}\n· · · · · · · · · · · · · ·\nreal ones only ☾`,

(l) => `🔥 lowkey elite\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n${l}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\ntap in 🔥`,

(l) => `⚡ main character energy\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n${l}\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\nenter your era ⚡`,

(l) => `🌙 you didn't see this\n✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦\n${l}\n✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦\njust join 🌙`,

(l) => `👑 vip invite only\n⟡─────────────────⟡\n${l}\n⟡─────────────────⟡\nact fast 👑`,

(l) => `🩷 soft life awaits\n♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡\n${l}\n♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡\nyou belong here 🩷`,

(l) => `✿ invitation only ✿\n⊱ ──────────────── ⊰\n${l}\n⊱ ──────────────── ⊰\nbloom with us ✿`,

(l) => `💫 rare link alert\n˚ · . · ˚ · . · ˚ · . · ˚\n${l}\n˚ · . · ˚ · . · ˚ · . · ˚\nwhile it lasts 💫`,

(l) => `🎯 one link. one chance.\n◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈\n${l}\n◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈\ndon't miss 🎯`,

(l) => `🌺 you're invited 🌺\n⊱ ─────────────── ⊰\n${l}\n⊱ ─────────────── ⊰\nstep inside ♡`,

(l) => `✧ silent flex ✧\n· ─ · ─ · ─ · ─ · ─ · ─ ·\n${l}\n· ─ · ─ · ─ · ─ · ─ · ─ ·\nreal ones know ✧`,

(l) => `🫧 soft but dangerous\n꒰ঌ ─────────────── ໒꒱\n${l}\n꒰ঌ ─────────────── ໒꒱\nenter if you dare 🫧`,

(l) => `💌 this is your sign\n━━━━━━━━━━━━━━━━━━━━\n${l}\n━━━━━━━━━━━━━━━━━━━━\ndon't ignore it 💌`,

(l) => `🌟 new era unlocked\n✦ · · · · · · · · · · ✦\n${l}\n✦ · · · · · · · · · · ✦\nstep in 🌟`,

(l) => `🍒 not for everyone\n ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸\n${l}\n ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂\nbut maybe you 🍒`,

(l) => `☁︎ cloud nine vibes ☁︎\n~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~\n${l}\n~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~\nfloat in ♡`,

(l) => `🔮 it's giving exclusive\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n${l}\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\njoin the wave 🔮`,

(l) => `🖤 lowkey drop 🖤\n▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬\n${l}\n▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬\nno noise ♡`,

(l) => `🌸 cherry blossom drop\n · ·❀· · · ·❀· · · ·❀· ·\n${l}\n · ·❀· · · ·❀· · · ·❀· ·\npetal in 🌸`,

(l) => `🎀 bow drop 🎀\n ‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌꒰ ‌‌‌ꔛ‌‌‌ ꒱\n${l}\n ‌‌‌‌꒰ ‌‌‌ꔛ‌‌‌ ꒱‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌\ntie yourself in 🎀`,

(l) => `(。♥‿♥。) kawaii drop\n°꒰ · ‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌ · ꒱°\n${l}\n°꒰ · ‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌ · ꒱°\ncutest invite yet (。♥‿♥。)`,

(l) => `✧ pearls only ✧\n· · ◎ · · · · ◎ · · · ◎ · ·\n${l}\n· · ◎ · · · · ◎ · · · ◎ · ·\nrare find ✧`,

(l) => `🌙 crescent invite 🌙\n˚✧₊⁺ · · · · · · · · ⁺₊✧˚\n${l}\n˚✧₊⁺ · · · · · · · · ⁺₊✧˚\ndream in ♡`,

(l) => `❀ blossom gate ❀\n─ · ─ · ❀ · ─ · ─ · ❀ · ─\n${l}\n─ · ─ · ❀ · ─ · ─ · ❀ · ─\nwalk through ❀`,

(l) => `≈ soft wave drop ≈\n≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈\n${l}\n≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈ ≈\nride in ≈`,

(l) => `🌙 moonbeam drop 🌙\n˚✧ · · · · · · · · · · ✧˚\n${l}\n˚✧ · · · · · · · · · · ✧˚\ncatch it before it fades 🌙`,

(l) => `⸻ dainty drop ⸻\n⸻ · ⸻ · ⸻ · ⸻\n${l}\n⸻ · ⸻ · ⸻ · ⸻\ndelicate & rare ⸻`,

(l) => `👑 tiara drop ✦\n✦ · · ◌ · · ✦ · · ◌ · · ✦\n${l}\n✦ · · ◌ · · ✦ · · ◌ · · ✦\ncrown yourself 👑`,

(l) => `🪻 lavender season\n‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌ · 🪻 · · · 🪻 · · · 🪻 ·\n${l}\n · 🪻 · · · 🪻 · · · 🪻 ·\nbloom in 🪻`,

(l) => `❄ frost drop ❄\n❄ · · · · · · · · · · · ❄\n${l}\n❄ · · · · · · · · · · · ❄\nchill and enter ❄`,

(l) => `◌ halo invite ◌\n◌ · ◌ · ◌ · ◌ · ◌ · ◌\n${l}\n◌ · ◌ · ◌ · ◌ · ◌ · ◌\nangel move ◌`,

(l) => `° ˖ wisp drop ✦\n° ˖ · ° ˖ · ° ˖ · ° ˖ · °\n${l}\n° ˖ · ° ˖ · ° ˖ · ° ˖ · °\nfollow the light ✦`,

(l) => `🌹 rose drop 🌹\n· · · · 🌹 · · · · 🌹 · · · ·\n${l}\n· · · · 🌹 · · · · 🌹 · · · ·\npetal by petal 🌹`,

(l) => `🍬 sweet drop 🍬\n˚ · ˚ · ˚ · ˚ · ˚ · ˚ · ˚\n${l}\n˚ · ˚ · ˚ · ˚ · ˚ · ˚ · ˚\ntreat yourself 🍬`,

(l) => `〔 ♡ 〕 ribbon bow drop\n── · ── · ── · ── · ──\n${l}\n── · ── · ── · ── · ──\nuntie it ♡`,

(l) => `✵ stardust drop ✵\n✵ · · ✵ · · ✵ · · ✵ · · ✵\n${l}\n✵ · · ✵ · · ✵ · · ✵ · · ✵\ncatch a star ✵`,

(l) => `🧚 nymph invite 🧚\n· ✧ · · · ✧ · · · ✧ · · · ✧\n${l}\n· ✧ · · · ✧ · · · ✧ · · · ✧\nfloat in 🧚`,

(l) => `🩷 blush drop 🩷\n🩷 · · · · · · · · · · · 🩷\n${l}\n🩷 · · · · · · · · · · · 🩷\nsoft and exclusive 🩷`,

(l) => `🍡 mochi drop 🍡\n‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌ · · · · ° · · · ° · · · ·\n${l}\n · · · · ° · · · ° · · · ·\nsweet & rare 🍡`,

(l) => `🌿 wisteria drop 🌿\n🌿 · · · · · 🌿 · · · · · 🌿\n${l}\n🌿 · · · · · 🌿 · · · · · 🌿\nground yourself here 🌿`,

(l) => `‿‿‿ silk drop ‿‿‿\n‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿\n${l}\n‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿ ‿\nsmooth like silk ♡`,

(l) => `∿ gossamer drop ∿\n∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿\n${l}\n∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿ ∿\nlight as air ∿`,

(l) => `☁️ dreamscape drop ☁️\n· · ☁️ · · · ☁️ · · · ☁️ · ·\n${l}\n· · ☁️ · · · ☁️ · · · ☁️ · ·\ndream your way in ♡`,

(l) => `🍃 pixie invite 🍃\n🍃 · · ✨ · · 🍃 · · ✨ · · 🍃\n${l}\n🍃 · · ✨ · · 🍃 · · ✨ · · 🍃\nlight and rare 🍃`,

(l) => `⁺ ˖ ° fairy dust ° ˖ ⁺\n⁺ ˖ ° ⁺ ˖ ° ⁺ ˖ ° ⁺ ˖\n${l}\n⁺ ˖ ° ⁺ ˖ ° ⁺ ˖ ° ⁺ ˖\nsprinkle in ♡`,

(l) => `🖤 prestige girly 🖤\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\n${l}\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\nno noise. just entry. 🖤`,

];

// ═══════════════════════════════════════════════════════════════════════════════
// GUYS / MASCULINE ENERGY THEME (55 designs)
// ═══════════════════════════════════════════════════════════════════════════════
const GUYS_T = [

(l) => `💯 no cap. this it.\n━━━━━━━━━━━━━━━━━━━━\n${l}\n━━━━━━━━━━━━━━━━━━━━\ntap in or stay losing 💯`,

(l) => `🔥 big moves only\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n${l}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nyou know what it is 🔥`,

(l) => `😤 real ones recognized\n◆─────────────────◆\n${l}\n◆─────────────────◆\nlink up or fall off 😤`,

(l) => `⚡ GRIND MODE ON\n▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸\n${l}\n◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂\nno weak energy here ⚡`,

(l) => `🗡 savage hours\n═══════════════════\n${l}\n═══════════════════\ncut through or stay out 🗡`,

(l) => `W energy only 💪\n┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄\n${l}\n┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄\nL's stay outside 💪`,

(l) => `🏆 built different\n◇━━━━━━━━━━━━━━━━━◇\n${l}\n◇━━━━━━━━━━━━━━━━━◇\nnormal ones swipe up 🏆`,

(l) => `🤫 no talkers allowed\n· ─ · ─ · ─ · ─ · ─\n${l}\n· ─ · ─ · ─ · ─ · ─\nactions only 🤫`,

(l) => `💰 the plug is live\n╔═══════════════════╗\n${l}\n╚═══════════════════╝\nget in or get left 💰`,

(l) => `🎯 locked in\n◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈\n${l}\n◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈\nno distractions 🎯`,

(l) => `🥇 elite circle\n⟫─────────────────⟪\n${l}\n⟫─────────────────⟪\nnot for everyone 🥇`,

(l) => `😮‍💨 pressure makes diamonds\n┼─┼─┼─┼─┼─┼─┼─┼─┼\n${l}\n┼─┼─┼─┼─┼─┼─┼─┼─┼\npressure applied 😮‍💨`,

(l) => `🦅 real G movement\n▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄\n${l}\n▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄\nflap different 🦅`,

(l) => `💎 certified drop\n⊱──────────────────⊰\n${l}\n⊱──────────────────⊰\ncertified or not invited 💎`,

(l) => `🛡 honor code\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n${l}\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\nstandards over everything 🛡`,

(l) => `🏋️ no days off\n█████░░░░░░░░░░░░░░\n${l}\n████████████████████\nresults require action 🏋️`,

(l) => `🔱 king's link\n╠══════════════════╣\n${l}\n╠══════════════════╣\nserfs don't qualify 🔱`,

(l) => `👊 earned not given\n═══════════════════\n${l}\n═══════════════════\nworth it or not 👊`,

(l) => `🧠 big brain move\n▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄\n${l}\n▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\nread the play 🧠`,

(l) => `🌑 dark horse drop\n ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n${l}\n ─ ─ ─ ─ ─ ─ ─ ─ ─ ─\nwatching from the shadows 🌑`,

(l) => `🎲 calculated risk\n◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤\n${l}\n◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥\nbet on yourself 🎲`,

(l) => `🔒 locked in squad\n┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃\n${l}\n┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃\nsolid or don't apply 🔒`,

(l) => `⚔️ battlefield open\n━┿━┿━┿━┿━┿━┿━┿━┿━\n${l}\n━┿━┿━┿━┿━┿━┿━┿━┿━\ncowards skip this ⚔️`,

(l) => `💡 big vision drop\n✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦\n${l}\n✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦\nsmall minds won't get it 💡`,

(l) => `🏴 black flag drop\n░░░░░░░░░░░░░░░░░░░\n${l}\n░░░░░░░░░░░░░░░░░░░\nwe don't explain moves 🏴`,

(l) => `🚀 launch sequence\n▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸\n${l}\n◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂\nignite or get left 🚀`,

(l) => `🥷 ghost move\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\n${l}\n⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇\nsilent and deadly 🥷`,

(l) => `💪 strength in numbers\n~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~\n${l}\n~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~\nlink or miss out 💪`,

(l) => `🎖 decorated drop\n◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇\n${l}\n◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇\nearned your spot 🎖`,

(l) => `⚡ voltage drop\n· · ─ ─ · · ─ ─ · · ─ ─ · ·\n${l}\n· · ─ ─ · · ─ ─ · · ─ ─ · ·\nshock to the system ⚡`,

(l) => `🏹 arrow aimed\n► ► ► ► ► ► ► ► ► ►\n${l}\n◄ ◄ ◄ ◄ ◄ ◄ ◄ ◄ ◄ ◄\nhit the target 🏹`,

(l) => `🌊 wave incoming\n≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋\n${l}\n≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋≋\nride or drown 🌊`,

(l) => `🔥 heat check\n▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌\n${l}\n▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐▐\nare you built for this? 🔥`,

(l) => `👁 watching the move\n╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌\n${l}\n╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌\ndon't miss the play 👁`,

(l) => `🧱 foundation drop\n█▓▒░░░░░░░░░░░░░░░░\n${l}\n████████████████████\nbuild on this 🧱`,

(l) => `🎯 precision drop\n╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍\n${l}\n╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍╍\nno strays here 🎯`,

(l) => `🌪 momentum shift\n⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫⟫\n${l}\n⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪⟪\nchange the tide 🌪`,

(l) => `🐺 wolf pack link\n▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬\n${l}\n▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬\nhowl or stay solo 🐺`,

(l) => `🎱 eight ball drop\n◆─────────────────◆\n${l}\n◆─────────────────◆\nbehind the eight ball 🎱`,

(l) => `🏔 summit access\n─═════════════════─\n${l}\n─═════════════════─\nnot for those who quit 🏔`,

(l) => `⚙️ machine running\n┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼\n${l}\n┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼\ncogs turning ⚙️`,

(l) => `🔋 fully charged drop\n[████████████████] 100%\n${l}\n[████████████████] GO\nmax energy only 🔋`,

(l) => `🌍 global move\n⬡─⬡─⬡─⬡─⬡─⬡─⬡─⬡\n${l}\n⬡─⬡─⬡─⬡─⬡─⬡─⬡─⬡\nno local mindset 🌍`,

(l) => `💼 business only\n╠═════════════════╣\n${l}\n╠═════════════════╣\nleave emotions outside 💼`,

(l) => `🔴 red zone drop\n┼─┼─┼─┼─┼─┼─┼─┼─┼\n${l}\n┼─┼─┼─┼─┼─┼─┼─┼─┼\ndanger zone entry 🔴`,

(l) => `🎯 one shot\n◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤◤\n${l}\n◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥◥\nmake it count 🎯`,

(l) => `🦁 lion's share\n⊱──────────────────⊰\n${l}\n⊱──────────────────⊰\nking energy only 🦁`,

(l) => `🎪 main event\n═══════════════════\n${l}\n═══════════════════\ncenter stage drop 🎪`,

(l) => `🧊 ice cold drop\n━━━━━━━━━━━━━━━━━━━━\n${l}\n━━━━━━━━━━━━━━━━━━━━\ncool heads only 🧊`,

(l) => `🌓 night shift drop\n· ─ · ─ · ─ · ─ · ─\n${l}\n· ─ · ─ · ─ · ─ · ─\nwhile they sleep 🌓`,

(l) => `🔑 key handed over\n╔─────────────────╗\n${l}\n╚─────────────────╝\ndon't lose it 🔑`,

(l) => `⚡ final voltage\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\n${l}\n⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡ ─ ⬡\nlast drop. last chance. ⚡`,

];

// ═══════════════════════════════════════════════════════════════════════════════
// THEME MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════
const VALID_THEMES = ['cyber', 'girly', 'guys'];

function setActiveTheme(theme) {
    const t = String(theme || '').toLowerCase().trim();
    if (!VALID_THEMES.includes(t)) throw new Error(`Unknown theme "${t}". Valid: ${VALID_THEMES.join(', ')}`);
    _activeTheme = t;
    _saveTheme();
    return _activeTheme;
}

function getActiveTheme() { return _activeTheme; }

function _getThemeTemplates(theme) {
    const t = String(theme || _activeTheme).toLowerCase();
    if (t === 'girly') return GIRLY_T;
    if (t === 'guys')  return GUYS_T;
    return CYBER_T;
}

// ── Per-group index store ──────────────────────────────────────────────────────
function getIndex(groupJid, theme) {
    const T = _getThemeTemplates(theme);
    const k = String(groupJid || '');
    // Store per theme: key = "jid::theme"
    const storeKey = theme ? `${k}::${theme}` : `${k}::${_activeTheme}`;
    if (_store[storeKey] !== undefined) return _store[storeKey];
    const idx = Math.floor(Math.random() * T.length);
    _store[storeKey] = idx;
    _saveStore();
    return idx;
}

function renderGodcastTemplate({ groupJid, inviteLink, templateIndex, theme } = {}) {
    try {
        const T   = _getThemeTemplates(theme);
        const idx = templateIndex !== undefined
            ? Math.max(0, Math.min(Number(templateIndex), T.length - 1))
            : getIndex(groupJid, theme);
        return (T[idx] || T[T.length - 1])(String(inviteLink || ''));
    } catch {
        const T = _getThemeTemplates(theme);
        return T[T.length - 1](String(inviteLink || ''));
    }
}

function resetGroupTemplate(groupJid) {
    // Clear all theme variants for this group
    for (const t of VALID_THEMES) {
        delete _store[`${String(groupJid || '')}::${t}`];
    }
    _saveStore();
}

function assignGroupTemplate(groupJid, idx, theme) {
    const T = _getThemeTemplates(theme);
    const t = String(theme || _activeTheme).toLowerCase();
    const storeKey = `${String(groupJid || '')}::${t}`;
    _store[storeKey] = Math.max(0, Math.min(Number(idx), T.length - 1));
    _saveStore();
}

module.exports = {
    CYBER_TEMPLATES:    CYBER_T,
    GIRLY_TEMPLATES:    GIRLY_T,
    GUYS_TEMPLATES:     GUYS_T,
    VALID_THEMES,
    TEMPLATE_COUNT:     CYBER_T.length,
    setActiveTheme,
    getActiveTheme,
    renderGodcastTemplate,
    getTemplateIndexForGroup: getIndex,
    resetGroupTemplate,
    assignGroupTemplate,
    // Legacy compat
    TEMPLATES: CYBER_T,
};
