#!/bin/bash
# Start Redis in background, then start the bot

echo "🔴 Starting Redis..."
redis-server --daemonize yes --logfile /tmp/redis.log --port 6379

sleep 1

echo "🤖 Starting Pappy Bot..."
cd "$(dirname "$0")"
node --expose-gc index.js
