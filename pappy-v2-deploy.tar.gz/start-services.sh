#!/usr/bin/env bash
# start-services.sh — Start Redis + MongoDB, then launch the bot

set -e

BOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="$BOT_DIR/data"
mkdir -p "$DATA_DIR/mongodb" "$DATA_DIR/redis"

echo "🔴 Starting Redis..."
redis-server --daemonize yes \
    --logfile "$DATA_DIR/redis.log" \
    --dir "$DATA_DIR/redis" \
    --port 6379 \
    --save ""

echo "🍃 Starting MongoDB..."
if ! pgrep -x mongod > /dev/null 2>&1; then
    mongod --fork \
        --logpath "$DATA_DIR/mongodb.log" \
        --dbpath "$DATA_DIR/mongodb" \
        --port 27017 \
        --bind_ip 127.0.0.1 \
        --quiet
else
    echo "   MongoDB already running."
fi

echo "✅ Services ready. Starting Pappy Bot..."
cd "$BOT_DIR"
node --expose-gc index.js
