'use strict';
// modules/menuEngine.js — PULSE aesthetic

const fs   = require('fs');
const path = require('path');
const { CAT_ICON, divider, accentLine, roleBadge, dateStamp, vibe } = require('./uiTheme');

const CATEGORY_ORDER = [
  'CORE','ADMIN','STATUS','MEDIA','MUSIC','IMAGE',
  'STICKER','AI','INTEL','NEXUS','WARMUP','SYSTEM','GENERAL',
];

const HEADER_VARIANTS = [
  [
    `┏━━━━━━━━━━━━━━━━━━━━━━━━┓`,
    `   👑 P A P P Y  •  E L I T E`,
    `┗━━━━━━━━━━━━━━━━━━━━━━━━┛`,
  ],
  [
    `┏━━━━━━━━━━━━━━━━━━━━━━━━┓`,
    `   ⚡ P A P P Y  N E X U S`,
    `┗━━━━━━━━━━━━━━━━━━━━━━━━┛`,
  ],
  [
    `┏━━━━━━━━━━━━━━━━━━━━━━━━┓`,
    `   🔥 P A P P Y  •  O N L I N E`,
    `┗━━━━━━━━━━━━━━━━━━━━━━━━┛`,
  ],
];

function generateMenu(user, opts = {}) {
  const userRole = String(opts.userRole || 'public').toLowerCase();
  const name     = String(user.name  || 'User');
  const ping     = user.ping  != null ? `${user.ping}ms` : '—';
  const cmds     = user.level != null ? user.level : 0;

  // Scan plugins for commands
  const pluginsDir = path.join(__dirname, '../plugins');
  const files      = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
  const menuMap    = {};
  const seen       = new Set();

  for (const file of files) {
    try {
      const plugin = require(path.join(pluginsDir, file));
      if (!plugin.commands) continue;
      const cat = String(plugin.category || 'GENERAL').toUpperCase();
      if (!menuMap[cat]) menuMap[cat] = [];
      for (const command of plugin.commands) {
        const cmdName = String(command.cmd || '').trim();
        if (!cmdName || seen.has(cmdName)) continue;
        if (!hasPermission(userRole, command.role)) continue;
        seen.add(cmdName);
        menuMap[cat].push(cmdName);
      }
    } catch {}
  }

  const header  = HEADER_VARIANTS[Math.floor(Math.random() * HEADER_VARIANTS.length)];
  const tagline = vibe();
  const cats    = [...new Set([...CATEGORY_ORDER, ...Object.keys(menuMap)])].filter(c => menuMap[c]?.length);
  const totalCmds = cats.reduce((sum, c) => sum + (menuMap[c]?.length || 0), 0);

  const lines = [''];

  // ── Header block ──────────────────────────────────────────────────────────
  for (const h of header) lines.push(h);
  lines.push('');

  // ── Profile card ──────────────────────────────────────────────────────────
  lines.push(`  👤 *${name}*  ·  ${roleBadge(userRole)}`);
  lines.push(`  ⚡ *${ping}*  ·  📊 *${cmds}* used  ·  🕐 ${dateStamp()}`);
  lines.push('');
  lines.push(`  ${accentLine(28)}`);
  lines.push(`  🔓 *${totalCmds}* commands unlocked across *${cats.length}* modules`);
  lines.push(`  ${divider(28)}`);
  lines.push('');

  // ── Command categories ────────────────────────────────────────────────────
  for (const cat of cats) {
    const list = menuMap[cat];
    if (!list?.length) continue;
    const icon = CAT_ICON[cat] || '✨';

    lines.push(`  ${icon} *${cat}*  ${'┄'.repeat(2)} ${list.length}`);

    // 2 columns, bullet-prefixed
    for (let i = 0; i < list.length; i += 2) {
      const a = `▸ ${list[i]}`.padEnd(20);
      const b = list[i + 1] ? `▸ ${list[i + 1]}` : '';
      lines.push(`  ${a}${b}`);
    }
    lines.push('');
  }

  // ── Footer ────────────────────────────────────────────────────────────────
  lines.push(`  ${accentLine(28)}`);
  lines.push(`  ✦ _"${tagline}"_`);
  lines.push(`  💡 _type any command exactly as shown_`);
  lines.push('');

  return lines.join('\n');
}

function hasPermission(userRole, requiredRole = 'owner') {
  const roles = { public: 1, admin: 2, owner: 3 };
  return (roles[userRole] || 1) >= (roles[requiredRole] || 3);
}

module.exports = { generateMenu };
