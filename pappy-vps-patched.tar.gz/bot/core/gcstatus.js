'use strict';
// core/gcstatus.js — @crysnovax/baileys groupStatus: true flag
// Wraps extendedTextMessage into externalAdReply so renderLargerThumbnail works

const logger           = require('./logger');
const linkPreviewCache = require('./linkPreviewCache');
const { normalizeThumbnailBuffer } = require('./linkPreview');

function reviveBuffer(v) {
    if (!v) return null;
    if (Buffer.isBuffer(v)) return v;
    if (v && v.type === 'Buffer' && Array.isArray(v.data)) return Buffer.from(v.data);
    return null;
}

async function sendGroupStatus(sock, groupJid, content, opts = {}) {
    if (!groupJid?.endsWith('@g.us')) throw new Error('Requires a valid @g.us JID');
    if (!sock?.user) throw new Error('Socket not connected');

    try { await sock.updateStatusPrivacy('all'); } catch {}

    const { sourceMessage } = opts;

    // ── PATH 1: source is an extendedTextMessage ──────────────────────────────
    // Rebuild as contextInfo.externalAdReply so renderLargerThumbnail: true fires
    if (sourceMessage?.extendedTextMessage) {
        const ext = sourceMessage.extendedTextMessage;
        // FIX A — prefer content.text over ext.text:
        //   • content.text comes from restText (command prefix stripped) or the aesthetic-
        //     wrapped text for godcast. ext.text is the RAW full message the user typed
        //     (e.g. ".updategstatus chat.whatsapp.com/...") which must NOT be posted.
        const txt = content.text || ext.text || '';
        if (txt) linkPreviewCache.cacheFromMessage({ message: { extendedTextMessage: ext } }, txt);

        const hasLink = !!(ext.matchedText || ext.canonicalUrl);

        // If the source has link preview data → rebuild as externalAdReply (large card)
        if (hasLink) {
            // FIX B — large thumbnail: ext.jpegThumbnail is the tiny 40×40 inline preview.
            // For WA group invite links, fetch the actual group profile pic and resize to 300×300.
            let thumb = null; // deliberately skip the tiny inline preview — start fresh
            const linkUrl = ext.matchedText || ext.canonicalUrl || '';
            const waInviteMatch = linkUrl.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/i);
            if (waInviteMatch) {
                try {
                    const axios = require('axios');
                    const sharp  = require('sharp');
                    const inviteInfo = await sock.groupGetInviteInfo(waInviteMatch[1]);
                    logger.info(`[GCStatus] Fetching profile pic for group: ${inviteInfo.id}`);
                    let rawBuf = null;
                    try {
                        const ppUrl = await sock.profilePictureUrl(inviteInfo.id, 'image');
                        if (ppUrl) {
                            const ppRes = await axios.get(ppUrl, { responseType: 'arraybuffer', timeout: 6000 });
                            rawBuf = Buffer.from(ppRes.data);
                            logger.info(`[GCStatus] Profile pic fetched: ${rawBuf.length} bytes`);
                        }
                    } catch (e) {
                        logger.warn(`[GCStatus] profilePictureUrl failed: ${e.message}`);
                    }
                    // Resize via the shared normalizer — large enough that WA renders a
                    // full-bleed card instead of a small cropped square.
                    if (rawBuf) {
                        thumb = await normalizeThumbnailBuffer(rawBuf);
                    } else {
                        // No profile pic — generate a large solid placeholder so the
                        // card still renders at full size (same as nativePreview.js)
                        thumb = await sharp({
                            create: { width: 1024, height: 1024, channels: 3, background: { r: 18, g: 140, b: 126 } }
                        }).jpeg({ quality: 85 }).toBuffer();
                        logger.info('[GCStatus] Using large green placeholder thumbnail');
                    }
                } catch (e) {
                    logger.warn(`[GCStatus] Thumb fetch failed: ${e.message} — falling back to inline preview`);
                    thumb = reviveBuffer(ext.jpegThumbnail);
                }
            } else {
                // Not a WA invite link — use whatever WA gave us
                thumb = reviveBuffer(ext.jpegThumbnail);
            }

            const adReply = {
                title:                 String(ext.title || '').slice(0, 100),
                body:                  String(ext.description || '').slice(0, 200),
                mediaType:             1,
                sourceUrl:             ext.canonicalUrl || ext.matchedText,
                renderLargerThumbnail: true,
                showAdAttribution:     false,
            };
            if (thumb && thumb.length > 0) {
                adReply.jpegThumbnail = thumb;
            }

            const result = await sock.sendMessage(groupJid, {
                text: txt,
                contextInfo: {
                    matchedText:    ext.matchedText || ext.canonicalUrl || '',
                    canonicalUrl:   ext.canonicalUrl || ext.matchedText || '',
                    'matched-text': ext.matchedText || ext.canonicalUrl || '',
                    externalAdReply: adReply,
                },
                groupStatus: true,
            });
            logger.info(`[GCStatus] Ring (externalAdReply large) -> ${groupJid}`);
            return result;
        }

        // No link data → relay fields as-is (text/font/color status)
        const result = await sock.sendMessage(groupJid, {
            text:                                  txt,
            ...(ext.matchedText    ? { matchedText:    ext.matchedText }    : {}),
            ...(ext.canonicalUrl   ? { canonicalUrl:   ext.canonicalUrl }   : {}),
            ...(ext.jpegThumbnail  ? { jpegThumbnail:  reviveBuffer(ext.jpegThumbnail) || ext.jpegThumbnail } : {}),
            ...(ext.title          ? { title:          ext.title }          : {}),
            ...(ext.description    ? { description:    ext.description }    : {}),
            ...(ext.backgroundArgb ? { backgroundArgb: ext.backgroundArgb } : {}),
            ...(ext.font           ? { font:           ext.font }           : {}),
            ...(ext.contextInfo    ? { contextInfo:    ext.contextInfo }    : {}),
            groupStatus: true,
        });
        logger.info(`[GCStatus] Ring (relay plain) -> ${groupJid}`);
        return result;
    }

    // ── PATH 1.5: no sourceMessage but text contains a WhatsApp group invite link ──
    // When user types `.updategstatus chat.whatsapp.com/...` directly (no quoted message
    // and no pre-loaded preview), sourceMessage is null and content is plain text.
    // FIX 3 — fetch the group info ourselves and build a large-thumbnail externalAdReply.
    if (!sourceMessage && content.text) {
        const waInviteMatch = String(content.text).match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/i);
        if (waInviteMatch) {
            try {
                const inviteCode = waInviteMatch[1];
                const inviteInfo = await sock.groupGetInviteInfo(inviteCode);
                let thumbBuf = null;
                try {
                    const axios = require('axios');
                    const ppUrl = await sock.profilePictureUrl(inviteInfo.id, 'image');
                    if (ppUrl) {
                        const ppRes = await axios.get(ppUrl, { responseType: 'arraybuffer', timeout: 5000 });
                        thumbBuf = await normalizeThumbnailBuffer(Buffer.from(ppRes.data));
                    }
                } catch {}
                const inviteUrl = `https://chat.whatsapp.com/${inviteCode}`;
                const adReply = {
                    title:                 String(inviteInfo.subject || 'WhatsApp Group').slice(0, 100),
                    body:                  String(inviteInfo.desc || inviteInfo.description || `${inviteInfo.participants?.length || 0} members`).slice(0, 200),
                    mediaType:             1,
                    sourceUrl:             inviteUrl,
                    renderLargerThumbnail: true,
                    showAdAttribution:     false,
                };
                if (thumbBuf) adReply.jpegThumbnail = thumbBuf;
                const result = await sock.sendMessage(groupJid, {
                    text: content.text,
                    contextInfo: {
                        matchedText:    inviteUrl,
                        canonicalUrl:   inviteUrl,
                        'matched-text': inviteUrl,
                        externalAdReply: adReply,
                    },
                    groupStatus: true,
                });
                logger.info(`[GCStatus] Ring (WA invite auto-preview) -> ${groupJid}`);
                return result;
            } catch (e) {
                logger.warn(`[GCStatus] WA invite auto-preview failed, falling through: ${e.message}`);
            }
        }
    }

    // ── PATH 2: contextInfo payload already built (from bullEngine) ───────────
    if (content.contextInfo?.externalAdReply) {
        // Force renderLargerThumbnail in case it wasn't set
        content.contextInfo.externalAdReply.renderLargerThumbnail = true;
        const result = await sock.sendMessage(groupJid, { ...content, groupStatus: true });
        logger.info(`[GCStatus] Ring (contextInfo) -> ${groupJid}`);
        return result;
    }

    // ── PATH 3: media ─────────────────────────────────────────────────────────
    if (content.image || content.video) {
        const result = await sock.sendMessage(groupJid, { ...content, groupStatus: true });
        logger.info(`[GCStatus] Ring (media) -> ${groupJid}`);
        return result;
    }

    // ── PATH 4: plain text ────────────────────────────────────────────────────
    const result = await sock.sendMessage(groupJid, { text: content.text || '🔱', groupStatus: true });
    logger.info(`[GCStatus] Ring (plain) -> ${groupJid}`);
    return result;
}

module.exports = { sendGroupStatus };
