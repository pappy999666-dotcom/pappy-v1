// plugins/group-status.js
const { broadcastQueue } = require('../core/bullEngine');
const logger = require('../core/logger');
const { getGroups } = require('../core/statusManager');

module.exports = {
    category: 'STATUS',
    commands: [
        { cmd: '.updategstatus', role: 'admin' },
        { cmd: '.gstatus', role: 'owner' }
    ],

    execute: async ({ sock, msg, args, text, botId }) => {
        const chat = msg.key.remoteJid;
        
        try {
            // Parse command
            const commandName = text.split(' ')[0].toLowerCase();
            const content = text.slice(commandName.length).trim() || '🔱';
            
            // Get target groups
            let targetJids = [];
            if (commandName === '.gstatus' && args[0]) {
                // Single group JID provided
                targetJids = [args[0]];
            } else {
                // Get all groups
                targetJids = await getGroups(sock);
            }
            
            if (!targetJids.length) {
                return sock.sendMessage(chat, { 
                    text: '⚠️ No groups found to post status.' 
                });
            }
            
            logger.info(`[GroupStatus] Queueing ${targetJids.length} jobs for ${botId}`);
            
            // Queue jobs for Bull worker
            const jobs = targetJids.map((jid, index) => ({
                name: `GS_${botId}_${jid}_${Date.now()}_${index}`,
                data: {
                    botId,
                    targetJid: jid,
                    mode: 'advanced_status',
                    commandType: 'groupstatus',
                    textContent: content,
                    font: 3,
                    backgroundColor: '#00C853',
                    useGhostProtocol: false
                },
                opts: {
                    removeOnComplete: true,
                    removeOnFail: false,
                    attempts: 3,
                    backoff: { type: 'exponential', delay: 3000 }
                }
            }));
            
            await broadcastQueue.addBulk(jobs);
            
            await sock.sendMessage(chat, {
                text: `✅ *Status Queued*\n📊 Groups: ${targetJids.length}\n⏳ Processing...`
            });
            
            logger.success(`[GroupStatus] Queued ${jobs.length} jobs successfully`);
            
        } catch (err) {
            logger.error(`[GroupStatus] Error: ${err.message}`);
            await sock.sendMessage(chat, { 
                text: `❌ Error: ${err.message}` 
            });
        }
    }
};
